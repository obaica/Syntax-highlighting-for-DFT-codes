cp2k.vim
========

Get syntax highlighting in VIM for your cp2k input files!

The ftdetect file is unique in this repository while the syntax file gets re-generated automatically using the XSL and the XML output from `cp2k --xml`, see [cp2k/tools/input_editing/vim](https://github.com/cp2k/cp2k/tree/master/tools/input_editing/vim).

This is a repository provided for your convenience when using [pathogen.vim](https://github.com/tpope/vim-pathogen) or similar tools to manage your VIM plug-ins.
